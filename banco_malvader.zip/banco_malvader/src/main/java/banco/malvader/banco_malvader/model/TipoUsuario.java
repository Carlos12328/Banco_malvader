package banco.malvader.banco_malvader.model;

public enum TipoUsuario {

    FUNCIONARIO,
    CLIENTE

}
