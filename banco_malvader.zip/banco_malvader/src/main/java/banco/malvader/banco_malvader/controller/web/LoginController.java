// LoginController.java
package banco.malvader.banco_malvader.controller.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import banco.malvader.banco_malvader.service.UsuarioService;


@Controller
public class LoginController {

    @GetMapping("/")
    public String create() {
        return "login";
    }


@PostMapping("/login")
public String autenticar(@RequestParam String cpf, @RequestParam String senha, Model model) {
    boolean loginValido = UsuarioService.verificarLogin(cpf, senha);

    if (loginValido) {
        return "redirect:/home"; // ou qualquer tela de sucesso
    } else {
        model.addAttribute("erro", "Usuário ou senha inválidos");
        return "login"; // volta para login com erro
    }
}
}
