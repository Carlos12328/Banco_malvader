package banco.malvader.banco_malvader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BancoMalvaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(BancoMalvaderApplication.class, args);
	}

}
