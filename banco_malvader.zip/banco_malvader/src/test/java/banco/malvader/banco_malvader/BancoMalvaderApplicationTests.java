package banco.malvader.banco_malvader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancoMalvaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
